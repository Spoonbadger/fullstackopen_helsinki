import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Togglable.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=c499ffd4"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/craigmorley/Documents/coding/fullstackopen/part5/bloglist-frontend/src/components/Togglable.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=c499ffd4"; const useState = __vite__cjsImport3_react["useState"]; const forwardRef = __vite__cjsImport3_react["forwardRef"]; const useImperativeHandle = __vite__cjsImport3_react["useImperativeHandle"];
import __vite__cjsImport4_propTypes from "/node_modules/.vite/deps/prop-types.js?v=c499ffd4"; const PropTypes = __vite__cjsImport4_propTypes.__esModule ? __vite__cjsImport4_propTypes.default : __vite__cjsImport4_propTypes;
const Togglable = _s(forwardRef(_c = _s((props, refs) => {
  _s();
  const [visible, setVisible] = useState(false);
  const hideWhenVisible = {
    display: visible ? "none" : ""
  };
  const showWhenVisible = {
    display: visible ? "" : "none"
  };
  const toggleVisibility = () => {
    setVisible(!visible);
  };
  useImperativeHandle(refs, () => {
    return {
      toggleVisibility
    };
  });
  Togglable.propTypes = {
    buttonLabel: PropTypes.string.isRequired
  };
  Togglable.displayName = "Togglable";
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("div", { style: hideWhenVisible, children: /* @__PURE__ */ jsxDEV("button", { onClick: toggleVisibility, children: props.buttonLabel }, void 0, false, {
      fileName: "/Users/craigmorley/Documents/coding/fullstackopen/part5/bloglist-frontend/src/components/Togglable.jsx",
      lineNumber: 27,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/craigmorley/Documents/coding/fullstackopen/part5/bloglist-frontend/src/components/Togglable.jsx",
      lineNumber: 26,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { style: showWhenVisible, children: [
      props.children,
      /* @__PURE__ */ jsxDEV("button", { onClick: toggleVisibility, children: "cancel" }, void 0, false, {
        fileName: "/Users/craigmorley/Documents/coding/fullstackopen/part5/bloglist-frontend/src/components/Togglable.jsx",
        lineNumber: 31,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/craigmorley/Documents/coding/fullstackopen/part5/bloglist-frontend/src/components/Togglable.jsx",
      lineNumber: 29,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/craigmorley/Documents/coding/fullstackopen/part5/bloglist-frontend/src/components/Togglable.jsx",
    lineNumber: 25,
    columnNumber: 10
  }, this);
}, "7Y5lBLdF9mkfoiy3F9Lk5HPUzvA=")), "7Y5lBLdF9mkfoiy3F9Lk5HPUzvA=");
_c2 = Togglable;
export default Togglable;
var _c, _c2;
$RefreshReg$(_c, "Togglable$forwardRef");
$RefreshReg$(_c2, "Togglable");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/craigmorley/Documents/coding/fullstackopen/part5/bloglist-frontend/src/components/Togglable.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNEJROzs7Ozs7Ozs7Ozs7Ozs7OztBQTVCUixTQUFTQSxVQUFVQyxZQUFZQywyQkFBMkI7QUFDMUQsT0FBT0MsZUFBZTtBQUV0QixNQUFNQyxZQUFTQyxHQUFHSixXQUFVSyxLQUFBRCxHQUFDLENBQUNFLE9BQU9DLFNBQVM7QUFBQUgsS0FBQTtBQUM1QyxRQUFNLENBQUNJLFNBQVNDLFVBQVUsSUFBSVYsU0FBUyxLQUFLO0FBRTVDLFFBQU1XLGtCQUFrQjtBQUFBLElBQUVDLFNBQVNILFVBQVUsU0FBUztBQUFBLEVBQUc7QUFDekQsUUFBTUksa0JBQWtCO0FBQUEsSUFBRUQsU0FBU0gsVUFBVSxLQUFLO0FBQUEsRUFBTztBQUV6RCxRQUFNSyxtQkFBbUJBLE1BQU07QUFDN0JKLGVBQVcsQ0FBQ0QsT0FBTztBQUFBLEVBQ3JCO0FBRUFQLHNCQUFvQk0sTUFBTSxNQUFNO0FBQzlCLFdBQU87QUFBQSxNQUNMTTtBQUFBQSxJQUNGO0FBQUEsRUFDRixDQUFDO0FBRURWLFlBQVVXLFlBQVk7QUFBQSxJQUNwQkMsYUFBYWIsVUFBVWMsT0FBT0M7QUFBQUEsRUFDaEM7QUFFQWQsWUFBVWUsY0FBYztBQUV4QixTQUNFLHVCQUFDLFNBQ0M7QUFBQSwyQkFBQyxTQUFJLE9BQU9SLGlCQUNWLGlDQUFDLFlBQU8sU0FBU0csa0JBQW1CUCxnQkFBTVMsZUFBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFzRCxLQUR4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxJQUNBLHVCQUFDLFNBQUksT0FBT0gsaUJBQ1ROO0FBQUFBLFlBQU1hO0FBQUFBLE1BQ1AsdUJBQUMsWUFBTyxTQUFTTixrQkFBa0Isc0JBQW5DO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBeUM7QUFBQSxTQUYzQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBR0E7QUFBQSxPQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FRQTtBQUVKLEdBQUMsa0NBQUM7QUFBQU8sTUFqQ0lqQjtBQW9DTixlQUFlQTtBQUFTLElBQUFFLElBQUFlO0FBQUFDLGFBQUFoQixJQUFBO0FBQUFnQixhQUFBRCxLQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJmb3J3YXJkUmVmIiwidXNlSW1wZXJhdGl2ZUhhbmRsZSIsIlByb3BUeXBlcyIsIlRvZ2dsYWJsZSIsIl9zIiwiX2MiLCJwcm9wcyIsInJlZnMiLCJ2aXNpYmxlIiwic2V0VmlzaWJsZSIsImhpZGVXaGVuVmlzaWJsZSIsImRpc3BsYXkiLCJzaG93V2hlblZpc2libGUiLCJ0b2dnbGVWaXNpYmlsaXR5IiwicHJvcFR5cGVzIiwiYnV0dG9uTGFiZWwiLCJzdHJpbmciLCJpc1JlcXVpcmVkIiwiZGlzcGxheU5hbWUiLCJjaGlsZHJlbiIsIl9jMiIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlRvZ2dsYWJsZS5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUsIGZvcndhcmRSZWYsIHVzZUltcGVyYXRpdmVIYW5kbGUgfSBmcm9tICdyZWFjdCdcbmltcG9ydCBQcm9wVHlwZXMgZnJvbSAncHJvcC10eXBlcydcblxuY29uc3QgVG9nZ2xhYmxlID0gZm9yd2FyZFJlZigocHJvcHMsIHJlZnMpID0+IHtcbiAgY29uc3QgW3Zpc2libGUsIHNldFZpc2libGVdID0gdXNlU3RhdGUoZmFsc2UpXG5cbiAgY29uc3QgaGlkZVdoZW5WaXNpYmxlID0geyBkaXNwbGF5OiB2aXNpYmxlID8gJ25vbmUnIDogJycgfVxuICBjb25zdCBzaG93V2hlblZpc2libGUgPSB7IGRpc3BsYXk6IHZpc2libGUgPyAnJyA6ICdub25lJyB9XG5cbiAgY29uc3QgdG9nZ2xlVmlzaWJpbGl0eSA9ICgpID0+IHtcbiAgICBzZXRWaXNpYmxlKCF2aXNpYmxlKVxuICB9XG5cbiAgdXNlSW1wZXJhdGl2ZUhhbmRsZShyZWZzLCAoKSA9PiB7XG4gICAgcmV0dXJuIHtcbiAgICAgIHRvZ2dsZVZpc2liaWxpdHlcbiAgICB9XG4gIH0pXG5cbiAgVG9nZ2xhYmxlLnByb3BUeXBlcyA9IHtcbiAgICBidXR0b25MYWJlbDogUHJvcFR5cGVzLnN0cmluZy5pc1JlcXVpcmVkXG4gIH1cblxuICBUb2dnbGFibGUuZGlzcGxheU5hbWUgPSAnVG9nZ2xhYmxlJ1xuXG4gIHJldHVybiAoXG4gICAgPGRpdj5cbiAgICAgIDxkaXYgc3R5bGU9e2hpZGVXaGVuVmlzaWJsZX0+XG4gICAgICAgIDxidXR0b24gb25DbGljaz17dG9nZ2xlVmlzaWJpbGl0eX0+e3Byb3BzLmJ1dHRvbkxhYmVsfTwvYnV0dG9uPlxuICAgICAgPC9kaXY+XG4gICAgICA8ZGl2IHN0eWxlPXtzaG93V2hlblZpc2libGV9PlxuICAgICAgICB7cHJvcHMuY2hpbGRyZW59XG4gICAgICAgIDxidXR0b24gb25DbGljaz17dG9nZ2xlVmlzaWJpbGl0eX0+Y2FuY2VsPC9idXR0b24+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKVxufSlcblxuXG5leHBvcnQgZGVmYXVsdCBUb2dnbGFibGUiXSwiZmlsZSI6Ii9Vc2Vycy9jcmFpZ21vcmxleS9Eb2N1bWVudHMvY29kaW5nL2Z1bGxzdGFja29wZW4vcGFydDUvYmxvZ2xpc3QtZnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvVG9nZ2xhYmxlLmpzeCJ9