import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=c499ffd4"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/craigmorley/Documents/coding/fullstackopen/part5/bloglist-frontend/src/App.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=c499ffd4"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useRef = __vite__cjsImport3_react["useRef"];
import Blog from "/src/components/Blog.jsx";
import BlogForm from "/src/components/BlogForm.jsx";
import LoginForm from "/src/components/LoginForm.jsx";
import Notification from "/src/components/Notification.jsx";
import Togglable from "/src/components/Togglable.jsx";
import blogService from "/src/services/blogs.js";
import loginService from "/src/services/login.js";
const App = () => {
  _s();
  const [blogs, setBlogs] = useState([]);
  const [user, setUser] = useState(null);
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [notification, setNotification] = useState(null);
  const [loginVisible, setLoginVisible] = useState(false);
  useEffect(() => {
    const loggedUserJSON = window.localStorage.getItem("loggedInBlogUser");
    if (loggedUserJSON) {
      const user2 = JSON.parse(loggedUserJSON);
      setUser(user2);
      blogService.setToken(user2.token);
    }
  }, []);
  useEffect(() => {
    const getBlogs = async () => {
      try {
        const blogs2 = await blogService.getAll();
        blogs2.sort((a, b) => b.likes - a.likes);
        setBlogs(blogs2);
        console.log("Fetched blogs:", blogs2);
      } catch (error) {
        console.log("Error fetching blogs:", error);
      }
    };
    getBlogs();
  }, []);
  const addBlog = async (blogObject) => {
    try {
      blogFormRef.current.toggleVisibility();
      const returnedBlog = await blogService.create(blogObject);
      setBlogs(blogs.concat(returnedBlog));
      setNotification({
        message: `New blog: ${blogObject.title} by ${blogObject.author} added`,
        type: "success"
      });
      setTimeout(() => {
        setNotification(null);
      }, 4500);
    } catch (exception) {
      setNotification({
        message: "failed to create new blog",
        type: "error"
      });
      console.log(exception);
      setTimeout(() => {
        setNotification(null);
      }, 4500);
    }
  };
  const updateTheLikeCount = async (updateBlog) => {
    const updatedBlog = await blogService.addLike(updateBlog);
    setBlogs((blogs2) => {
      const updatedBlogs = blogs2.map((blog) => blog.id === updatedBlog.id ? updateBlog : blog);
      return updatedBlogs.sort((a, b) => b.likes - a.likes);
    });
  };
  console.log("userinfo:", user);
  const deleteBlog = async (blogToGo) => {
    window.confirm(`delete this blog ${blogToGo.title}?`);
    await blogService.deleteBlog(blogToGo);
    setBlogs((blogs2) => {
      return blogs2.filter((blog) => blog.id !== blogToGo.id);
    });
  };
  const loginForm = () => {
    const hideWhenVisible = {
      display: loginVisible ? "none" : ""
    };
    const showWhenVisible = {
      display: loginVisible ? "" : "none"
    };
    return /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV("div", { style: hideWhenVisible, children: /* @__PURE__ */ jsxDEV("button", { onClick: () => setLoginVisible(true), children: "log in" }, void 0, false, {
        fileName: "/Users/craigmorley/Documents/coding/fullstackopen/part5/bloglist-frontend/src/App.jsx",
        lineNumber: 99,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "/Users/craigmorley/Documents/coding/fullstackopen/part5/bloglist-frontend/src/App.jsx",
        lineNumber: 98,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { style: showWhenVisible, children: [
        /* @__PURE__ */ jsxDEV(LoginForm, { username, password, handleUsernameChange: ({
          target
        }) => setUsername(target.value), handlePasswordChange: ({
          target
        }) => setPassword(target.value), handleSubmit: handleLogin }, void 0, false, {
          fileName: "/Users/craigmorley/Documents/coding/fullstackopen/part5/bloglist-frontend/src/App.jsx",
          lineNumber: 102,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("button", { onClick: () => setLoginVisible(false), children: "cancel" }, void 0, false, {
          fileName: "/Users/craigmorley/Documents/coding/fullstackopen/part5/bloglist-frontend/src/App.jsx",
          lineNumber: 107,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/craigmorley/Documents/coding/fullstackopen/part5/bloglist-frontend/src/App.jsx",
        lineNumber: 101,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/craigmorley/Documents/coding/fullstackopen/part5/bloglist-frontend/src/App.jsx",
      lineNumber: 97,
      columnNumber: 12
    }, this);
  };
  const handleLogin = async (event) => {
    event.preventDefault();
    console.log("HandlingLogin with...", username, password);
    try {
      const user2 = await loginService.login({
        username,
        password
      });
      if (!user2) {
        console.log("no user :( ):", user2);
      }
      console.log("userinfo:", user2);
      window.localStorage.setItem("loggedInBlogUser", JSON.stringify(user2));
      blogService.setToken(user2.token);
      setUser(user2);
      setUsername("");
      setPassword("");
    } catch (exception) {
      setNotification({
        message: "Incorrect credentials",
        type: "error"
      });
      setTimeout(() => {
        setNotification(null);
      }, 4500);
    }
  };
  const handleLogout = async (event) => {
    event.preventDefault();
    setNotification({
      message: `${user.name} logged out.`,
      type: "error"
    });
    setTimeout(() => {
      setNotification(null);
    }, 4e3);
    window.localStorage.clear();
    setUser(null);
  };
  const blogFormRef = useRef();
  const blogForm = () => /* @__PURE__ */ jsxDEV(Togglable, { buttonLabel: "new blog", ref: blogFormRef, children: /* @__PURE__ */ jsxDEV(BlogForm, { createBlog: addBlog }, void 0, false, {
    fileName: "/Users/craigmorley/Documents/coding/fullstackopen/part5/bloglist-frontend/src/App.jsx",
    lineNumber: 152,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/craigmorley/Documents/coding/fullstackopen/part5/bloglist-frontend/src/App.jsx",
    lineNumber: 151,
    columnNumber: 26
  }, this);
  if (user === null) {
    return /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV("h2", { children: "Log in to application" }, void 0, false, {
        fileName: "/Users/craigmorley/Documents/coding/fullstackopen/part5/bloglist-frontend/src/App.jsx",
        lineNumber: 156,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Notification, { message: notification?.message, type: notification?.type }, void 0, false, {
        fileName: "/Users/craigmorley/Documents/coding/fullstackopen/part5/bloglist-frontend/src/App.jsx",
        lineNumber: 157,
        columnNumber: 9
      }, this),
      loginForm()
    ] }, void 0, true, {
      fileName: "/Users/craigmorley/Documents/coding/fullstackopen/part5/bloglist-frontend/src/App.jsx",
      lineNumber: 155,
      columnNumber: 12
    }, this);
  }
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("h2", { children: "blogs" }, void 0, false, {
      fileName: "/Users/craigmorley/Documents/coding/fullstackopen/part5/bloglist-frontend/src/App.jsx",
      lineNumber: 162,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Notification, { message: notification?.message, type: notification?.type }, void 0, false, {
      fileName: "/Users/craigmorley/Documents/coding/fullstackopen/part5/bloglist-frontend/src/App.jsx",
      lineNumber: 163,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("p", { children: [
      /* @__PURE__ */ jsxDEV("span", { children: [
        user.name,
        " logged in"
      ] }, void 0, true, {
        fileName: "/Users/craigmorley/Documents/coding/fullstackopen/part5/bloglist-frontend/src/App.jsx",
        lineNumber: 164,
        columnNumber: 10
      }, this),
      /* @__PURE__ */ jsxDEV("button", { "data-testid": "logout-button", onClick: handleLogout, children: "logout" }, void 0, false, {
        fileName: "/Users/craigmorley/Documents/coding/fullstackopen/part5/bloglist-frontend/src/App.jsx",
        lineNumber: 164,
        columnNumber: 44
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/craigmorley/Documents/coding/fullstackopen/part5/bloglist-frontend/src/App.jsx",
      lineNumber: 164,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { children: blogForm() }, void 0, false, {
      fileName: "/Users/craigmorley/Documents/coding/fullstackopen/part5/bloglist-frontend/src/App.jsx",
      lineNumber: 165,
      columnNumber: 7
    }, this),
    blogs.map((blog) => /* @__PURE__ */ jsxDEV(Blog, { blog, updateTheLikeCount, deleteBlog, user }, blog.id, false, {
      fileName: "/Users/craigmorley/Documents/coding/fullstackopen/part5/bloglist-frontend/src/App.jsx",
      lineNumber: 168,
      columnNumber: 26
    }, this))
  ] }, void 0, true, {
    fileName: "/Users/craigmorley/Documents/coding/fullstackopen/part5/bloglist-frontend/src/App.jsx",
    lineNumber: 161,
    columnNumber: 10
  }, this);
};
_s(App, "eJX75VT6nWI42UY+3WX7kSpFnDI=");
_c = App;
export default App;
var _c;
$RefreshReg$(_c, "App");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/craigmorley/Documents/coding/fullstackopen/part5/bloglist-frontend/src/App.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMkZVOzs7Ozs7Ozs7Ozs7Ozs7OztBQTNGVixTQUFTQSxVQUFVQyxXQUFXQyxjQUFjO0FBQzVDLE9BQU9DLFVBQVU7QUFDakIsT0FBT0MsY0FBYztBQUNyQixPQUFPQyxlQUFlO0FBQ3RCLE9BQU9DLGtCQUFrQjtBQUN6QixPQUFPQyxlQUFlO0FBQ3RCLE9BQU9DLGlCQUFpQjtBQUN4QixPQUFPQyxrQkFBa0I7QUFHekIsTUFBTUMsTUFBTUEsTUFBTTtBQUFBQyxLQUFBO0FBQ2hCLFFBQU0sQ0FBQ0MsT0FBT0MsUUFBUSxJQUFJYixTQUFTLEVBQUU7QUFDckMsUUFBTSxDQUFDYyxNQUFNQyxPQUFPLElBQUlmLFNBQVMsSUFBSTtBQUNyQyxRQUFNLENBQUNnQixVQUFVQyxXQUFXLElBQUlqQixTQUFTLEVBQUU7QUFDM0MsUUFBTSxDQUFDa0IsVUFBVUMsV0FBVyxJQUFJbkIsU0FBUyxFQUFFO0FBQzNDLFFBQU0sQ0FBQ29CLGNBQWNDLGVBQWUsSUFBSXJCLFNBQVMsSUFBSTtBQUNyRCxRQUFNLENBQUNzQixjQUFjQyxlQUFlLElBQUl2QixTQUFTLEtBQUs7QUFJdERDLFlBQVUsTUFBTTtBQUNkLFVBQU11QixpQkFBaUJDLE9BQU9DLGFBQWFDLFFBQVEsa0JBQWtCO0FBQ3JFLFFBQUlILGdCQUFnQjtBQUNsQixZQUFNVixRQUFPYyxLQUFLQyxNQUFNTCxjQUFjO0FBQ3RDVCxjQUFRRCxLQUFJO0FBQ1pOLGtCQUFZc0IsU0FBU2hCLE1BQUtpQixLQUFLO0FBQUEsSUFDakM7QUFBQSxFQUNGLEdBQUcsRUFBRTtBQUdMOUIsWUFBVSxNQUFNO0FBQ2QsVUFBTStCLFdBQVcsWUFBWTtBQUMzQixVQUFJO0FBQUUsY0FBTXBCLFNBQVEsTUFBTUosWUFBWXlCLE9BQU87QUFDM0NyQixlQUFNc0IsS0FBSyxDQUFDQyxHQUFHQyxNQUFNQSxFQUFFQyxRQUFRRixFQUFFRSxLQUFLO0FBQ3RDeEIsaUJBQVNELE1BQUs7QUFDZDBCLGdCQUFRQyxJQUFJLGtCQUFrQjNCLE1BQUs7QUFBQSxNQUNyQyxTQUFRNEIsT0FBTztBQUNiRixnQkFBUUMsSUFBSSx5QkFBeUJDLEtBQUs7QUFBQSxNQUM1QztBQUFBLElBQ0Y7QUFDQVIsYUFBUztBQUFBLEVBQ1gsR0FBRyxFQUFFO0FBR0wsUUFBTVMsVUFBVSxPQUFPQyxlQUFlO0FBQ3BDLFFBQUk7QUFDRkMsa0JBQVlDLFFBQVFDLGlCQUFpQjtBQUNyQyxZQUFNQyxlQUFlLE1BQU10QyxZQUFZdUMsT0FBT0wsVUFBVTtBQUN4RDdCLGVBQVNELE1BQU1vQyxPQUFPRixZQUFZLENBQUM7QUFDbkN6QixzQkFBZ0I7QUFBQSxRQUFFNEIsU0FBVSxhQUFZUCxXQUFXUSxLQUFNLE9BQU1SLFdBQVdTLE1BQU87QUFBQSxRQUFTQyxNQUFLO0FBQUEsTUFBVSxDQUFDO0FBQzFHQyxpQkFBVyxNQUFNO0FBQ2ZoQyx3QkFBZ0IsSUFBSTtBQUFBLE1BQ3RCLEdBQUcsSUFBSTtBQUFBLElBQ1QsU0FBUWlDLFdBQVc7QUFDakJqQyxzQkFBZ0I7QUFBQSxRQUFFNEIsU0FBUztBQUFBLFFBQTZCRyxNQUFLO0FBQUEsTUFBUSxDQUFDO0FBQ3RFZCxjQUFRQyxJQUFJZSxTQUFTO0FBQ3JCRCxpQkFBVyxNQUFNO0FBQ2ZoQyx3QkFBZ0IsSUFBSTtBQUFBLE1BQ3RCLEdBQUcsSUFBSTtBQUFBLElBQ1Q7QUFBQSxFQUNGO0FBR0EsUUFBTWtDLHFCQUFxQixPQUFPQyxlQUFlO0FBQy9DLFVBQU1DLGNBQWMsTUFBTWpELFlBQVlrRCxRQUFRRixVQUFVO0FBQ3hEM0MsYUFBVUQsWUFBVTtBQUNsQixZQUFNK0MsZUFBZS9DLE9BQU1nRCxJQUFJQyxVQUFRQSxLQUFLQyxPQUFPTCxZQUFZSyxLQUFLTixhQUFhSyxJQUFJO0FBQ3JGLGFBQU9GLGFBQWF6QixLQUFLLENBQUNDLEdBQUdDLE1BQU1BLEVBQUVDLFFBQVFGLEVBQUVFLEtBQUs7QUFBQSxJQUN0RCxDQUFDO0FBQUEsRUFDSDtBQUdBQyxVQUFRQyxJQUFJLGFBQWF6QixJQUFJO0FBRTdCLFFBQU1pRCxhQUFhLE9BQU9DLGFBQWE7QUFDckN2QyxXQUFPd0MsUUFBUyxvQkFBbUJELFNBQVNkLEtBQU0sR0FBRTtBQUNwRCxVQUFNMUMsWUFBWXVELFdBQVdDLFFBQVE7QUFDckNuRCxhQUFVRCxZQUFVO0FBQ2xCLGFBQU9BLE9BQU1zRCxPQUFPTCxVQUFRQSxLQUFLQyxPQUFPRSxTQUFTRixFQUFFO0FBQUEsSUFDckQsQ0FBQztBQUFBLEVBQ0g7QUFJQSxRQUFNSyxZQUFZQSxNQUFNO0FBQ3RCLFVBQU1DLGtCQUFrQjtBQUFBLE1BQUVDLFNBQVMvQyxlQUFlLFNBQVM7QUFBQSxJQUFHO0FBQzlELFVBQU1nRCxrQkFBa0I7QUFBQSxNQUFFRCxTQUFTL0MsZUFBZSxLQUFLO0FBQUEsSUFBTztBQUU5RCxXQUNFLHVCQUFDLFNBQ0M7QUFBQSw2QkFBQyxTQUFJLE9BQU84QyxpQkFDVixpQ0FBQyxZQUFPLFNBQVMsTUFBTTdDLGdCQUFnQixJQUFJLEdBQUcsc0JBQTlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBb0QsS0FEdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLE9BQU8rQyxpQkFDVjtBQUFBLCtCQUFDLGFBQ0MsVUFDQSxVQUNBLHNCQUFzQixDQUFDO0FBQUEsVUFBRUM7QUFBQUEsUUFBTyxNQUFNdEQsWUFBWXNELE9BQU9DLEtBQUssR0FDOUQsc0JBQXNCLENBQUM7QUFBQSxVQUFFRDtBQUFBQSxRQUFPLE1BQU1wRCxZQUFZb0QsT0FBT0MsS0FBSyxHQUM5RCxjQUFjQyxlQUxoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBSzRCO0FBQUEsUUFFNUIsdUJBQUMsWUFBTyxTQUFTLE1BQU1sRCxnQkFBZ0IsS0FBSyxHQUFHLHNCQUEvQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXFEO0FBQUEsV0FSdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVNBO0FBQUEsU0FiRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBY0E7QUFBQSxFQUVKO0FBRUEsUUFBTWtELGNBQWMsT0FBT0MsVUFBVTtBQUNuQ0EsVUFBTUMsZUFBZTtBQUNyQnJDLFlBQVFDLElBQUkseUJBQXlCdkIsVUFBVUUsUUFBUTtBQUN2RCxRQUFJO0FBQ0YsWUFBTUosUUFBTyxNQUFNTCxhQUFhbUUsTUFBTTtBQUFBLFFBQ3BDNUQ7QUFBQUEsUUFBVUU7QUFBQUEsTUFDWixDQUFDO0FBQ0QsVUFBSSxDQUFDSixPQUFNO0FBQ1R3QixnQkFBUUMsSUFBSSxpQkFBaUJ6QixLQUFJO0FBQUEsTUFDbkM7QUFDQXdCLGNBQVFDLElBQUksYUFBYXpCLEtBQUk7QUFFN0JXLGFBQU9DLGFBQWFtRCxRQUNsQixvQkFBb0JqRCxLQUFLa0QsVUFBVWhFLEtBQUksQ0FDekM7QUFDQU4sa0JBQVlzQixTQUFTaEIsTUFBS2lCLEtBQUs7QUFDL0JoQixjQUFRRCxLQUFJO0FBQ1pHLGtCQUFZLEVBQUU7QUFDZEUsa0JBQVksRUFBRTtBQUFBLElBQ2hCLFNBQVFtQyxXQUFXO0FBQ2pCakMsc0JBQWdCO0FBQUEsUUFBRTRCLFNBQVM7QUFBQSxRQUF5QkcsTUFBSztBQUFBLE1BQVEsQ0FBQztBQUNsRUMsaUJBQVcsTUFBTTtBQUNmaEMsd0JBQWdCLElBQUk7QUFBQSxNQUN0QixHQUFHLElBQUk7QUFBQSxJQUNUO0FBQUEsRUFDRjtBQUVBLFFBQU0wRCxlQUFlLE9BQU9MLFVBQVU7QUFDcENBLFVBQU1DLGVBQWU7QUFDckJ0RCxvQkFBZ0I7QUFBQSxNQUFFNEIsU0FBVSxHQUFFbkMsS0FBS2tFLElBQUs7QUFBQSxNQUFlNUIsTUFBSztBQUFBLElBQVEsQ0FBQztBQUNyRUMsZUFBVyxNQUFNO0FBQ2ZoQyxzQkFBZ0IsSUFBSTtBQUFBLElBQ3RCLEdBQUcsR0FBSTtBQUNQSSxXQUFPQyxhQUFhdUQsTUFBTTtBQUMxQmxFLFlBQVEsSUFBSTtBQUFBLEVBQ2Q7QUFFQSxRQUFNNEIsY0FBY3pDLE9BQU87QUFDM0IsUUFBTWdGLFdBQVdBLE1BQ2YsdUJBQUMsYUFBVSxhQUFZLFlBQVcsS0FBS3ZDLGFBQ3JDLGlDQUFDLFlBQVMsWUFBWUYsV0FBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUE4QixLQURoQztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBRUE7QUFHRixNQUFJM0IsU0FBUyxNQUFNO0FBQ2pCLFdBQ0UsdUJBQUMsU0FDQztBQUFBLDZCQUFDLFFBQUcscUNBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF5QjtBQUFBLE1BQ3pCLHVCQUFDLGdCQUFhLFNBQVVNLGNBQWM2QixTQUFVLE1BQU83QixjQUFjZ0MsUUFBckU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEyRTtBQUFBLE1BQzFFZSxVQUFVO0FBQUEsU0FIYjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBSUE7QUFBQSxFQUNEO0FBRUgsU0FDRSx1QkFBQyxTQUNDO0FBQUEsMkJBQUMsUUFBRyxxQkFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQVM7QUFBQSxJQUNULHVCQUFDLGdCQUFhLFNBQVUvQyxjQUFjNkIsU0FBVSxNQUFPN0IsY0FBY2dDLFFBQXJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBMEU7QUFBQSxJQUMxRSx1QkFBQyxPQUFFO0FBQUEsNkJBQUMsVUFBTXRDO0FBQUFBLGFBQUtrRTtBQUFBQSxRQUFLO0FBQUEsV0FBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEyQjtBQUFBLE1BQU8sdUJBQUMsWUFBTyxlQUFZLGlCQUFnQixTQUFTRCxjQUFjLHNCQUEzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWlFO0FBQUEsU0FBdEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUErRztBQUFBLElBQy9HLHVCQUFDLFNBQ0VHLG1CQUFTLEtBRFo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsSUFDQ3RFLE1BQU1nRCxJQUFJQyxVQUNULHVCQUFDLFFBRUMsTUFDQSxvQkFDQSxZQUNBLFFBSktBLEtBQUtDLElBRFo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUthLENBRWY7QUFBQSxPQWZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FnQkE7QUFFSjtBQUFDbkQsR0F6S0tELEtBQUc7QUFBQXlFLEtBQUh6RTtBQTRLTixlQUFlQTtBQUFHLElBQUF5RTtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJ1c2VFZmZlY3QiLCJ1c2VSZWYiLCJCbG9nIiwiQmxvZ0Zvcm0iLCJMb2dpbkZvcm0iLCJOb3RpZmljYXRpb24iLCJUb2dnbGFibGUiLCJibG9nU2VydmljZSIsImxvZ2luU2VydmljZSIsIkFwcCIsIl9zIiwiYmxvZ3MiLCJzZXRCbG9ncyIsInVzZXIiLCJzZXRVc2VyIiwidXNlcm5hbWUiLCJzZXRVc2VybmFtZSIsInBhc3N3b3JkIiwic2V0UGFzc3dvcmQiLCJub3RpZmljYXRpb24iLCJzZXROb3RpZmljYXRpb24iLCJsb2dpblZpc2libGUiLCJzZXRMb2dpblZpc2libGUiLCJsb2dnZWRVc2VySlNPTiIsIndpbmRvdyIsImxvY2FsU3RvcmFnZSIsImdldEl0ZW0iLCJKU09OIiwicGFyc2UiLCJzZXRUb2tlbiIsInRva2VuIiwiZ2V0QmxvZ3MiLCJnZXRBbGwiLCJzb3J0IiwiYSIsImIiLCJsaWtlcyIsImNvbnNvbGUiLCJsb2ciLCJlcnJvciIsImFkZEJsb2ciLCJibG9nT2JqZWN0IiwiYmxvZ0Zvcm1SZWYiLCJjdXJyZW50IiwidG9nZ2xlVmlzaWJpbGl0eSIsInJldHVybmVkQmxvZyIsImNyZWF0ZSIsImNvbmNhdCIsIm1lc3NhZ2UiLCJ0aXRsZSIsImF1dGhvciIsInR5cGUiLCJzZXRUaW1lb3V0IiwiZXhjZXB0aW9uIiwidXBkYXRlVGhlTGlrZUNvdW50IiwidXBkYXRlQmxvZyIsInVwZGF0ZWRCbG9nIiwiYWRkTGlrZSIsInVwZGF0ZWRCbG9ncyIsIm1hcCIsImJsb2ciLCJpZCIsImRlbGV0ZUJsb2ciLCJibG9nVG9HbyIsImNvbmZpcm0iLCJmaWx0ZXIiLCJsb2dpbkZvcm0iLCJoaWRlV2hlblZpc2libGUiLCJkaXNwbGF5Iiwic2hvd1doZW5WaXNpYmxlIiwidGFyZ2V0IiwidmFsdWUiLCJoYW5kbGVMb2dpbiIsImV2ZW50IiwicHJldmVudERlZmF1bHQiLCJsb2dpbiIsInNldEl0ZW0iLCJzdHJpbmdpZnkiLCJoYW5kbGVMb2dvdXQiLCJuYW1lIiwiY2xlYXIiLCJibG9nRm9ybSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiQXBwLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0LCB1c2VSZWYgfSBmcm9tICdyZWFjdCdcbmltcG9ydCBCbG9nIGZyb20gJy4vY29tcG9uZW50cy9CbG9nJ1xuaW1wb3J0IEJsb2dGb3JtIGZyb20gJy4vY29tcG9uZW50cy9CbG9nRm9ybSdcbmltcG9ydCBMb2dpbkZvcm0gZnJvbSAnLi9jb21wb25lbnRzL0xvZ2luRm9ybSdcbmltcG9ydCBOb3RpZmljYXRpb24gZnJvbSAnLi9jb21wb25lbnRzL05vdGlmaWNhdGlvbidcbmltcG9ydCBUb2dnbGFibGUgZnJvbSAnLi9jb21wb25lbnRzL1RvZ2dsYWJsZSdcbmltcG9ydCBibG9nU2VydmljZSBmcm9tICcuL3NlcnZpY2VzL2Jsb2dzJ1xuaW1wb3J0IGxvZ2luU2VydmljZSBmcm9tICcuL3NlcnZpY2VzL2xvZ2luJ1xuXG5cbmNvbnN0IEFwcCA9ICgpID0+IHtcbiAgY29uc3QgW2Jsb2dzLCBzZXRCbG9nc10gPSB1c2VTdGF0ZShbXSlcbiAgY29uc3QgW3VzZXIsIHNldFVzZXJdID0gdXNlU3RhdGUobnVsbClcbiAgY29uc3QgW3VzZXJuYW1lLCBzZXRVc2VybmFtZV0gPSB1c2VTdGF0ZSgnJylcbiAgY29uc3QgW3Bhc3N3b3JkLCBzZXRQYXNzd29yZF0gPSB1c2VTdGF0ZSgnJylcbiAgY29uc3QgW25vdGlmaWNhdGlvbiwgc2V0Tm90aWZpY2F0aW9uXSA9IHVzZVN0YXRlKG51bGwpXG4gIGNvbnN0IFtsb2dpblZpc2libGUsIHNldExvZ2luVmlzaWJsZV0gPSB1c2VTdGF0ZShmYWxzZSlcblxuICAvLyBJZiB0aGUgdXNlciBpcyBsb2dnZWQgaW4gYW5kIHNldCBpbiBsb2NhbCBzdG9yYWdlLFxuICAvLyBzYXZlIHVzZXIgaW4gc2Vzc2lvbiB3aXRoIG5ldyB0b2tlblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGNvbnN0IGxvZ2dlZFVzZXJKU09OID0gd2luZG93LmxvY2FsU3RvcmFnZS5nZXRJdGVtKCdsb2dnZWRJbkJsb2dVc2VyJylcbiAgICBpZiAobG9nZ2VkVXNlckpTT04pIHtcbiAgICAgIGNvbnN0IHVzZXIgPSBKU09OLnBhcnNlKGxvZ2dlZFVzZXJKU09OKVxuICAgICAgc2V0VXNlcih1c2VyKVxuICAgICAgYmxvZ1NlcnZpY2Uuc2V0VG9rZW4odXNlci50b2tlbilcbiAgICB9XG4gIH0sIFtdKVxuXG4gIC8vIFNob3cgYmxvZ3NcbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBjb25zdCBnZXRCbG9ncyA9IGFzeW5jICgpID0+IHtcbiAgICAgIHRyeSB7IGNvbnN0IGJsb2dzID0gYXdhaXQgYmxvZ1NlcnZpY2UuZ2V0QWxsKClcbiAgICAgICAgYmxvZ3Muc29ydCgoYSwgYikgPT4gYi5saWtlcyAtIGEubGlrZXMpXG4gICAgICAgIHNldEJsb2dzKGJsb2dzKVxuICAgICAgICBjb25zb2xlLmxvZygnRmV0Y2hlZCBibG9nczonLCBibG9ncylcbiAgICAgIH0gY2F0Y2goZXJyb3IpIHtcbiAgICAgICAgY29uc29sZS5sb2coJ0Vycm9yIGZldGNoaW5nIGJsb2dzOicsIGVycm9yKVxuICAgICAgfVxuICAgIH1cbiAgICBnZXRCbG9ncygpXG4gIH0sIFtdKVxuXG4gIC8vIEFkZCBhIGJsb2dcbiAgY29uc3QgYWRkQmxvZyA9IGFzeW5jIChibG9nT2JqZWN0KSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIGJsb2dGb3JtUmVmLmN1cnJlbnQudG9nZ2xlVmlzaWJpbGl0eSgpXG4gICAgICBjb25zdCByZXR1cm5lZEJsb2cgPSBhd2FpdCBibG9nU2VydmljZS5jcmVhdGUoYmxvZ09iamVjdClcbiAgICAgIHNldEJsb2dzKGJsb2dzLmNvbmNhdChyZXR1cm5lZEJsb2cpKVxuICAgICAgc2V0Tm90aWZpY2F0aW9uKHsgbWVzc2FnZTogYE5ldyBibG9nOiAke2Jsb2dPYmplY3QudGl0bGV9IGJ5ICR7YmxvZ09iamVjdC5hdXRob3J9IGFkZGVkYCwgdHlwZTonc3VjY2VzcycgfSlcbiAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICBzZXROb3RpZmljYXRpb24obnVsbClcbiAgICAgIH0sIDQ1MDApXG4gICAgfSBjYXRjaChleGNlcHRpb24pIHtcbiAgICAgIHNldE5vdGlmaWNhdGlvbih7IG1lc3NhZ2U6ICdmYWlsZWQgdG8gY3JlYXRlIG5ldyBibG9nJywgdHlwZTonZXJyb3InIH0pXG4gICAgICBjb25zb2xlLmxvZyhleGNlcHRpb24pXG4gICAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgc2V0Tm90aWZpY2F0aW9uKG51bGwpXG4gICAgICB9LCA0NTAwKVxuICAgIH1cbiAgfVxuXG4gIC8vIFVwZGF0aW5nIHRoZSBsaWtlIGNvdW50XG4gIGNvbnN0IHVwZGF0ZVRoZUxpa2VDb3VudCA9IGFzeW5jICh1cGRhdGVCbG9nKSA9PiB7XG4gICAgY29uc3QgdXBkYXRlZEJsb2cgPSBhd2FpdCBibG9nU2VydmljZS5hZGRMaWtlKHVwZGF0ZUJsb2cpXG4gICAgc2V0QmxvZ3MoKGJsb2dzKSA9PiB7XG4gICAgICBjb25zdCB1cGRhdGVkQmxvZ3MgPSBibG9ncy5tYXAoYmxvZyA9PiBibG9nLmlkID09PSB1cGRhdGVkQmxvZy5pZCA/IHVwZGF0ZUJsb2cgOiBibG9nKVxuICAgICAgcmV0dXJuIHVwZGF0ZWRCbG9ncy5zb3J0KChhLCBiKSA9PiBiLmxpa2VzIC0gYS5saWtlcylcbiAgICB9KVxuICB9XG5cbiAgLy8gRGVsZXRlIG93biBibG9nIGVudHJ5XG4gIGNvbnNvbGUubG9nKCd1c2VyaW5mbzonLCB1c2VyKVxuXG4gIGNvbnN0IGRlbGV0ZUJsb2cgPSBhc3luYyAoYmxvZ1RvR28pID0+IHtcbiAgICB3aW5kb3cuY29uZmlybShgZGVsZXRlIHRoaXMgYmxvZyAke2Jsb2dUb0dvLnRpdGxlfT9gKVxuICAgIGF3YWl0IGJsb2dTZXJ2aWNlLmRlbGV0ZUJsb2coYmxvZ1RvR28pXG4gICAgc2V0QmxvZ3MoKGJsb2dzKSA9PiB7XG4gICAgICByZXR1cm4gYmxvZ3MuZmlsdGVyKGJsb2cgPT4gYmxvZy5pZCAhPT0gYmxvZ1RvR28uaWQpXG4gICAgfSlcbiAgfVxuICBcblxuICAvLyBEaXNwbGF5IHVzZXIgZm9ybSBpZiB1c2VyIHNlbGVjdHMgdG8gbG9naW5cbiAgY29uc3QgbG9naW5Gb3JtID0gKCkgPT4ge1xuICAgIGNvbnN0IGhpZGVXaGVuVmlzaWJsZSA9IHsgZGlzcGxheTogbG9naW5WaXNpYmxlID8gJ25vbmUnIDogJycgfVxuICAgIGNvbnN0IHNob3dXaGVuVmlzaWJsZSA9IHsgZGlzcGxheTogbG9naW5WaXNpYmxlID8gJycgOiAnbm9uZScgfVxuXG4gICAgcmV0dXJuIChcbiAgICAgIDxkaXY+XG4gICAgICAgIDxkaXYgc3R5bGU9e2hpZGVXaGVuVmlzaWJsZX0+XG4gICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBzZXRMb2dpblZpc2libGUodHJ1ZSl9PmxvZyBpbjwvYnV0dG9uPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdiBzdHlsZT17c2hvd1doZW5WaXNpYmxlfT5cbiAgICAgICAgICA8TG9naW5Gb3JtXG4gICAgICAgICAgICB1c2VybmFtZT17dXNlcm5hbWV9XG4gICAgICAgICAgICBwYXNzd29yZD17cGFzc3dvcmR9XG4gICAgICAgICAgICBoYW5kbGVVc2VybmFtZUNoYW5nZT17KHsgdGFyZ2V0IH0pID0+IHNldFVzZXJuYW1lKHRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICBoYW5kbGVQYXNzd29yZENoYW5nZT17KHsgdGFyZ2V0IH0pID0+IHNldFBhc3N3b3JkKHRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICBoYW5kbGVTdWJtaXQ9e2hhbmRsZUxvZ2lufVxuICAgICAgICAgIC8+XG4gICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBzZXRMb2dpblZpc2libGUoZmFsc2UpfT5jYW5jZWw8L2J1dHRvbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICApXG4gIH1cblxuICBjb25zdCBoYW5kbGVMb2dpbiA9IGFzeW5jIChldmVudCkgPT4ge1xuICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KClcbiAgICBjb25zb2xlLmxvZygnSGFuZGxpbmdMb2dpbiB3aXRoLi4uJywgdXNlcm5hbWUsIHBhc3N3b3JkKVxuICAgIHRyeSB7XG4gICAgICBjb25zdCB1c2VyID0gYXdhaXQgbG9naW5TZXJ2aWNlLmxvZ2luKHtcbiAgICAgICAgdXNlcm5hbWUsIHBhc3N3b3JkXG4gICAgICB9KVxuICAgICAgaWYgKCF1c2VyKSB7XG4gICAgICAgIGNvbnNvbGUubG9nKCdubyB1c2VyIDooICk6JywgdXNlcilcbiAgICAgIH1cbiAgICAgIGNvbnNvbGUubG9nKCd1c2VyaW5mbzonLCB1c2VyKVxuXG4gICAgICB3aW5kb3cubG9jYWxTdG9yYWdlLnNldEl0ZW0oXG4gICAgICAgICdsb2dnZWRJbkJsb2dVc2VyJywgSlNPTi5zdHJpbmdpZnkodXNlcilcbiAgICAgIClcbiAgICAgIGJsb2dTZXJ2aWNlLnNldFRva2VuKHVzZXIudG9rZW4pXG4gICAgICBzZXRVc2VyKHVzZXIpXG4gICAgICBzZXRVc2VybmFtZSgnJylcbiAgICAgIHNldFBhc3N3b3JkKCcnKVxuICAgIH0gY2F0Y2goZXhjZXB0aW9uKSB7XG4gICAgICBzZXROb3RpZmljYXRpb24oeyBtZXNzYWdlOiAnSW5jb3JyZWN0IGNyZWRlbnRpYWxzJywgdHlwZTonZXJyb3InIH0pXG4gICAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgc2V0Tm90aWZpY2F0aW9uKG51bGwpXG4gICAgICB9LCA0NTAwKVxuICAgIH1cbiAgfVxuXG4gIGNvbnN0IGhhbmRsZUxvZ291dCA9IGFzeW5jIChldmVudCkgPT4ge1xuICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KClcbiAgICBzZXROb3RpZmljYXRpb24oeyBtZXNzYWdlOiBgJHt1c2VyLm5hbWV9IGxvZ2dlZCBvdXQuYCwgdHlwZTonZXJyb3InIH0pXG4gICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICBzZXROb3RpZmljYXRpb24obnVsbClcbiAgICB9LCA0MDAwKVxuICAgIHdpbmRvdy5sb2NhbFN0b3JhZ2UuY2xlYXIoKVxuICAgIHNldFVzZXIobnVsbClcbiAgfVxuXG4gIGNvbnN0IGJsb2dGb3JtUmVmID0gdXNlUmVmKClcbiAgY29uc3QgYmxvZ0Zvcm0gPSAoKSA9PiAoXG4gICAgPFRvZ2dsYWJsZSBidXR0b25MYWJlbD0nbmV3IGJsb2cnIHJlZj17YmxvZ0Zvcm1SZWZ9PlxuICAgICAgPEJsb2dGb3JtIGNyZWF0ZUJsb2c9e2FkZEJsb2d9IC8+XG4gICAgPC9Ub2dnbGFibGU+XG4gIClcblxuICBpZiAodXNlciA9PT0gbnVsbCkge1xuICAgIHJldHVybiAoXG4gICAgICA8ZGl2PlxuICAgICAgICA8aDI+TG9nIGluIHRvIGFwcGxpY2F0aW9uPC9oMj5cbiAgICAgICAgPE5vdGlmaWNhdGlvbiBtZXNzYWdlPXsgbm90aWZpY2F0aW9uPy5tZXNzYWdlIH0gdHlwZT17IG5vdGlmaWNhdGlvbj8udHlwZSB9IC8+XG4gICAgICAgIHtsb2dpbkZvcm0oKX1cbiAgICAgIDwvZGl2PlxuICAgICl9XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2PlxuICAgICAgPGgyPmJsb2dzPC9oMj5cbiAgICAgIDxOb3RpZmljYXRpb24gbWVzc2FnZT17IG5vdGlmaWNhdGlvbj8ubWVzc2FnZSB9IHR5cGU9eyBub3RpZmljYXRpb24/LnR5cGV9Lz5cbiAgICAgIDxwPjxzcGFuPnt1c2VyLm5hbWV9IGxvZ2dlZCBpbjwvc3Bhbj48YnV0dG9uIGRhdGEtdGVzdGlkPVwibG9nb3V0LWJ1dHRvblwiIG9uQ2xpY2s9e2hhbmRsZUxvZ291dH0+bG9nb3V0PC9idXR0b24+PC9wPlxuICAgICAgPGRpdj5cbiAgICAgICAge2Jsb2dGb3JtKCl9XG4gICAgICA8L2Rpdj5cbiAgICAgIHtibG9ncy5tYXAoYmxvZyA9PlxuICAgICAgICA8QmxvZ1xuICAgICAgICAgIGtleT17YmxvZy5pZH1cbiAgICAgICAgICBibG9nPXtibG9nfVxuICAgICAgICAgIHVwZGF0ZVRoZUxpa2VDb3VudD17dXBkYXRlVGhlTGlrZUNvdW50fVxuICAgICAgICAgIGRlbGV0ZUJsb2c9e2RlbGV0ZUJsb2d9XG4gICAgICAgICAgdXNlcj17dXNlcn1cbiAgICAgICAgLz5cbiAgICAgICl9XG4gICAgPC9kaXY+XG4gIClcbn1cblxuXG5leHBvcnQgZGVmYXVsdCBBcHAiXSwiZmlsZSI6Ii9Vc2Vycy9jcmFpZ21vcmxleS9Eb2N1bWVudHMvY29kaW5nL2Z1bGxzdGFja29wZW4vcGFydDUvYmxvZ2xpc3QtZnJvbnRlbmQvc3JjL0FwcC5qc3gifQ==