import {
  require_react
} from "/node_modules/.vite/deps/chunk-7JGOPB4S.js?v=c499ffd4";
import "/node_modules/.vite/deps/chunk-6TJCVOLN.js?v=c499ffd4";
export default require_react();
//# sourceMappingURL=react.js.map
