import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/BlogForm.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=c499ffd4"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/craigmorley/Documents/coding/fullstackopen/part5/bloglist-frontend/src/components/BlogForm.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=c499ffd4"; const useState = __vite__cjsImport3_react["useState"];
const BlogForm = ({
  createBlog
}) => {
  _s();
  const [newBlog, setNewBlog] = useState({
    title: "",
    author: "",
    url: ""
  });
  const addBlog = (event) => {
    event.preventDefault();
    createBlog({
      title: newBlog.title,
      author: newBlog.author,
      url: newBlog.url
    });
    setNewBlog({
      title: "",
      author: "",
      url: ""
    });
  };
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("h3", { children: "create a new blog" }, void 0, false, {
      fileName: "/Users/craigmorley/Documents/coding/fullstackopen/part5/bloglist-frontend/src/components/BlogForm.jsx",
      lineNumber: 26,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("form", { onSubmit: addBlog, children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        "title:",
        /* @__PURE__ */ jsxDEV("input", { type: "text", className: "title", "data-testid": "title", value: newBlog.title, onChange: (event) => setNewBlog({
          ...newBlog,
          title: event.target.value
        }), required: true }, void 0, false, {
          fileName: "/Users/craigmorley/Documents/coding/fullstackopen/part5/bloglist-frontend/src/components/BlogForm.jsx",
          lineNumber: 30,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/craigmorley/Documents/coding/fullstackopen/part5/bloglist-frontend/src/components/BlogForm.jsx",
        lineNumber: 28,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        "author:",
        /* @__PURE__ */ jsxDEV("input", { type: "text", className: "author", "data-testid": "author", value: newBlog.author, onChange: (event) => setNewBlog({
          ...newBlog,
          author: event.target.value
        }), required: true }, void 0, false, {
          fileName: "/Users/craigmorley/Documents/coding/fullstackopen/part5/bloglist-frontend/src/components/BlogForm.jsx",
          lineNumber: 37,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/craigmorley/Documents/coding/fullstackopen/part5/bloglist-frontend/src/components/BlogForm.jsx",
        lineNumber: 35,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        "url:",
        /* @__PURE__ */ jsxDEV("input", { type: "text", className: "url", "data-testid": "url", value: newBlog.url, onChange: (event) => setNewBlog({
          ...newBlog,
          url: event.target.value
        }), required: true }, void 0, false, {
          fileName: "/Users/craigmorley/Documents/coding/fullstackopen/part5/bloglist-frontend/src/components/BlogForm.jsx",
          lineNumber: 44,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/craigmorley/Documents/coding/fullstackopen/part5/bloglist-frontend/src/components/BlogForm.jsx",
        lineNumber: 42,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("button", { "data-testid": "create", type: "submit", children: "create" }, void 0, false, {
        fileName: "/Users/craigmorley/Documents/coding/fullstackopen/part5/bloglist-frontend/src/components/BlogForm.jsx",
        lineNumber: 49,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/craigmorley/Documents/coding/fullstackopen/part5/bloglist-frontend/src/components/BlogForm.jsx",
      lineNumber: 27,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/craigmorley/Documents/coding/fullstackopen/part5/bloglist-frontend/src/components/BlogForm.jsx",
    lineNumber: 25,
    columnNumber: 10
  }, this);
};
_s(BlogForm, "K/tN8NRnJMKJ8njMUg+eQKPnUio=");
_c = BlogForm;
export default BlogForm;
var _c;
$RefreshReg$(_c, "BlogForm");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/craigmorley/Documents/coding/fullstackopen/part5/bloglist-frontend/src/components/BlogForm.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaUJNOzs7Ozs7Ozs7Ozs7Ozs7OztBQWpCTixTQUFTQSxnQkFBZ0I7QUFFekIsTUFBTUMsV0FBV0EsQ0FBQztBQUFBLEVBQUVDO0FBQVcsTUFBTTtBQUFBQyxLQUFBO0FBQ25DLFFBQU0sQ0FBQ0MsU0FBU0MsVUFBVSxJQUFJTCxTQUFTO0FBQUEsSUFBRU0sT0FBTztBQUFBLElBQUlDLFFBQVE7QUFBQSxJQUFJQyxLQUFLO0FBQUEsRUFBRyxDQUFDO0FBRXpFLFFBQU1DLFVBQVdDLFdBQVU7QUFDekJBLFVBQU1DLGVBQWU7QUFDckJULGVBQVk7QUFBQSxNQUNWSSxPQUFPRixRQUFRRTtBQUFBQSxNQUNmQyxRQUFRSCxRQUFRRztBQUFBQSxNQUNoQkMsS0FBS0osUUFBUUk7QUFBQUEsSUFDZixDQUFDO0FBQ0RILGVBQVc7QUFBQSxNQUFFQyxPQUFPO0FBQUEsTUFBSUMsUUFBUTtBQUFBLE1BQUlDLEtBQUs7QUFBQSxJQUFHLENBQUM7QUFBQSxFQUMvQztBQUVBLFNBQ0UsdUJBQUMsU0FDQztBQUFBLDJCQUFDLFFBQUcsaUNBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFxQjtBQUFBLElBQ3JCLHVCQUFDLFVBQUssVUFBVUMsU0FDZDtBQUFBLDZCQUFDLFNBQUc7QUFBQTtBQUFBLFFBRUYsdUJBQUMsV0FDQyxNQUFLLFFBQ0wsV0FBVSxTQUNWLGVBQVksU0FDWixPQUFPTCxRQUFRRSxPQUNmLFVBQVVJLFdBQVNMLFdBQVc7QUFBQSxVQUFFLEdBQUdEO0FBQUFBLFVBQVNFLE9BQU9JLE1BQU1FLE9BQU9DO0FBQUFBLFFBQU0sQ0FBQyxHQUN2RSxVQUFRLFFBTlY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU1VO0FBQUEsV0FSWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBVUE7QUFBQSxNQUNBLHVCQUFDLFNBQUc7QUFBQTtBQUFBLFFBRUYsdUJBQUMsV0FDQyxNQUFLLFFBQ0wsV0FBVSxVQUNWLGVBQVksVUFDWixPQUFPVCxRQUFRRyxRQUNmLFVBQVVHLFdBQVNMLFdBQVc7QUFBQSxVQUFFLEdBQUdEO0FBQUFBLFVBQVNHLFFBQVFHLE1BQU1FLE9BQU9DO0FBQUFBLFFBQU0sQ0FBQyxHQUN4RSxVQUFRLFFBTlY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU1VO0FBQUEsV0FSWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBVUE7QUFBQSxNQUNBLHVCQUFDLFNBQUc7QUFBQTtBQUFBLFFBRUYsdUJBQUMsV0FDQyxNQUFLLFFBQ0wsV0FBVSxPQUNWLGVBQVksT0FDWixPQUFPVCxRQUFRSSxLQUNmLFVBQVVFLFdBQVNMLFdBQVc7QUFBQSxVQUFFLEdBQUdEO0FBQUFBLFVBQVNJLEtBQUtFLE1BQU1FLE9BQU9DO0FBQUFBLFFBQU0sQ0FBQyxHQUNyRSxVQUFRLFFBTlY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU1VO0FBQUEsV0FSWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBVUE7QUFBQSxNQUNBLHVCQUFDLFlBQU8sZUFBWSxVQUFTLE1BQUssVUFBUyxzQkFBM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFpRDtBQUFBLFNBbENuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBbUNBO0FBQUEsT0FyQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXNDQTtBQUVKO0FBQUNWLEdBdERLRixVQUFRO0FBQUFhLEtBQVJiO0FBeUROLGVBQWVBO0FBQVEsSUFBQWE7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwiQmxvZ0Zvcm0iLCJjcmVhdGVCbG9nIiwiX3MiLCJuZXdCbG9nIiwic2V0TmV3QmxvZyIsInRpdGxlIiwiYXV0aG9yIiwidXJsIiwiYWRkQmxvZyIsImV2ZW50IiwicHJldmVudERlZmF1bHQiLCJ0YXJnZXQiLCJ2YWx1ZSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiQmxvZ0Zvcm0uanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnXG5cbmNvbnN0IEJsb2dGb3JtID0gKHsgY3JlYXRlQmxvZyB9KSA9PiB7XG4gIGNvbnN0IFtuZXdCbG9nLCBzZXROZXdCbG9nXSA9IHVzZVN0YXRlKHsgdGl0bGU6ICcnLCBhdXRob3I6ICcnLCB1cmw6ICcnIH0pXG5cbiAgY29uc3QgYWRkQmxvZyA9IChldmVudCkgPT4ge1xuICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KClcbiAgICBjcmVhdGVCbG9nICh7XG4gICAgICB0aXRsZTogbmV3QmxvZy50aXRsZSxcbiAgICAgIGF1dGhvcjogbmV3QmxvZy5hdXRob3IsXG4gICAgICB1cmw6IG5ld0Jsb2cudXJsLFxuICAgIH0pXG4gICAgc2V0TmV3QmxvZyh7IHRpdGxlOiAnJywgYXV0aG9yOiAnJywgdXJsOiAnJyB9KVxuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2PlxuICAgICAgPGgzPmNyZWF0ZSBhIG5ldyBibG9nPC9oMz5cbiAgICAgIDxmb3JtIG9uU3VibWl0PXthZGRCbG9nfT5cbiAgICAgICAgPGRpdj5cbiAgICAgICAgICB0aXRsZTpcbiAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInRpdGxlXCJcbiAgICAgICAgICAgIGRhdGEtdGVzdGlkPVwidGl0bGVcIlxuICAgICAgICAgICAgdmFsdWU9e25ld0Jsb2cudGl0bGV9XG4gICAgICAgICAgICBvbkNoYW5nZT17ZXZlbnQgPT4gc2V0TmV3QmxvZyh7IC4uLm5ld0Jsb2csIHRpdGxlOiBldmVudC50YXJnZXQudmFsdWUgfSl9XG4gICAgICAgICAgICByZXF1aXJlZFxuICAgICAgICAgIC8+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2PlxuICAgICAgICAgIGF1dGhvcjpcbiAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImF1dGhvclwiXG4gICAgICAgICAgICBkYXRhLXRlc3RpZD1cImF1dGhvclwiXG4gICAgICAgICAgICB2YWx1ZT17bmV3QmxvZy5hdXRob3J9XG4gICAgICAgICAgICBvbkNoYW5nZT17ZXZlbnQgPT4gc2V0TmV3QmxvZyh7IC4uLm5ld0Jsb2csIGF1dGhvcjogZXZlbnQudGFyZ2V0LnZhbHVlIH0pfVxuICAgICAgICAgICAgcmVxdWlyZWRcbiAgICAgICAgICAvPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdj5cbiAgICAgICAgICB1cmw6XG4gICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJ1cmxcIlxuICAgICAgICAgICAgZGF0YS10ZXN0aWQ9XCJ1cmxcIlxuICAgICAgICAgICAgdmFsdWU9e25ld0Jsb2cudXJsfVxuICAgICAgICAgICAgb25DaGFuZ2U9e2V2ZW50ID0+IHNldE5ld0Jsb2coeyAuLi5uZXdCbG9nLCB1cmw6IGV2ZW50LnRhcmdldC52YWx1ZSB9KX1cbiAgICAgICAgICAgIHJlcXVpcmVkXG4gICAgICAgICAgLz5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxidXR0b24gZGF0YS10ZXN0aWQ9XCJjcmVhdGVcIiB0eXBlPVwic3VibWl0XCI+Y3JlYXRlPC9idXR0b24+XG4gICAgICA8L2Zvcm0+XG4gICAgPC9kaXY+XG4gIClcbn1cblxuXG5leHBvcnQgZGVmYXVsdCBCbG9nRm9ybSJdLCJmaWxlIjoiL1VzZXJzL2NyYWlnbW9ybGV5L0RvY3VtZW50cy9jb2RpbmcvZnVsbHN0YWNrb3Blbi9wYXJ0NS9ibG9nbGlzdC1mcm9udGVuZC9zcmMvY29tcG9uZW50cy9CbG9nRm9ybS5qc3gifQ==