import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Blog.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=c499ffd4"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/craigmorley/Documents/coding/fullstackopen/part5/bloglist-frontend/src/components/Blog.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=c499ffd4"; const useState = __vite__cjsImport3_react["useState"];
const Blog = ({
  blog,
  updateTheLikeCount,
  deleteBlog,
  user
}) => {
  _s();
  const blogStyle = {
    paddingTop: 5,
    paddingLeft: 5,
    border: "solid",
    borderWidth: 1,
    borderRadius: 5,
    marginTop: 5
  };
  const buttonStyle = {
    margin: 5
  };
  const [infoVisible, setInfoVisible] = useState(false);
  const hideWhenInfoVisible = {
    display: infoVisible ? "none" : ""
  };
  const showWhenInfoVisible = {
    display: infoVisible ? "" : "none"
  };
  const toggleVisibility = () => {
    setInfoVisible(!infoVisible);
  };
  const handleLike = async () => {
    const updatedBlog = {
      ...blog,
      likes: blog.likes + 1
    };
    updateTheLikeCount(updatedBlog);
  };
  const blogPoster = blog.user ? user.blogs.some((userBlog) => userBlog.user === blog.user.id) : false;
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("div", { style: hideWhenInfoVisible, children: /* @__PURE__ */ jsxDEV("div", { className: "blog-title-author", style: blogStyle, children: [
      blog.title,
      " ",
      blog.author,
      /* @__PURE__ */ jsxDEV("button", { onClick: toggleVisibility, style: buttonStyle, children: "view" }, void 0, false, {
        fileName: "/Users/craigmorley/Documents/coding/fullstackopen/part5/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 45,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/craigmorley/Documents/coding/fullstackopen/part5/bloglist-frontend/src/components/Blog.jsx",
      lineNumber: 43,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/craigmorley/Documents/coding/fullstackopen/part5/bloglist-frontend/src/components/Blog.jsx",
      lineNumber: 42,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { style: showWhenInfoVisible, children: /* @__PURE__ */ jsxDEV("div", { className: "expandedBlogView", style: blogStyle, children: [
      /* @__PURE__ */ jsxDEV("div", { className: "blog-title", children: [
        blog.title,
        /* @__PURE__ */ jsxDEV("button", { onClick: toggleVisibility, style: buttonStyle, children: "hide" }, void 0, false, {
          fileName: "/Users/craigmorley/Documents/coding/fullstackopen/part5/bloglist-frontend/src/components/Blog.jsx",
          lineNumber: 51,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/craigmorley/Documents/coding/fullstackopen/part5/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 50,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { "data-testid": "blog-url", children: blog.url }, void 0, false, {
        fileName: "/Users/craigmorley/Documents/coding/fullstackopen/part5/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 53,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { "data-testid": "blog-likes", children: [
        "likes: ",
        blog.likes,
        /* @__PURE__ */ jsxDEV("button", { "data-testid": "like-button", onClick: handleLike, style: buttonStyle, children: "like" }, void 0, false, {
          fileName: "/Users/craigmorley/Documents/coding/fullstackopen/part5/bloglist-frontend/src/components/Blog.jsx",
          lineNumber: 55,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/craigmorley/Documents/coding/fullstackopen/part5/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 54,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "blog-author", children: blog.author }, void 0, false, {
        fileName: "/Users/craigmorley/Documents/coding/fullstackopen/part5/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 57,
        columnNumber: 11
      }, this),
      blogPoster && /* @__PURE__ */ jsxDEV("button", { style: buttonStyle, onClick: () => deleteBlog(blog), children: "delete" }, void 0, false, {
        fileName: "/Users/craigmorley/Documents/coding/fullstackopen/part5/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 58,
        columnNumber: 26
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/craigmorley/Documents/coding/fullstackopen/part5/bloglist-frontend/src/components/Blog.jsx",
      lineNumber: 49,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/craigmorley/Documents/coding/fullstackopen/part5/bloglist-frontend/src/components/Blog.jsx",
      lineNumber: 48,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/craigmorley/Documents/coding/fullstackopen/part5/bloglist-frontend/src/components/Blog.jsx",
    lineNumber: 41,
    columnNumber: 10
  }, this);
};
_s(Blog, "fth1nDCLKefC7Mw6LvkiPd/+uRo=");
_c = Blog;
export default Blog;
var _c;
$RefreshReg$(_c, "Blog");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/craigmorley/Documents/coding/fullstackopen/part5/bloglist-frontend/src/components/Blog.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNENVOzs7Ozs7Ozs7Ozs7Ozs7OztBQTVDVixTQUFTQSxnQkFBZ0I7QUFFekIsTUFBTUMsT0FBT0EsQ0FBQztBQUFBLEVBQUVDO0FBQUFBLEVBQU1DO0FBQUFBLEVBQW9CQztBQUFBQSxFQUFZQztBQUFLLE1BQU07QUFBQUMsS0FBQTtBQUMvRCxRQUFNQyxZQUFZO0FBQUEsSUFDaEJDLFlBQVk7QUFBQSxJQUNaQyxhQUFhO0FBQUEsSUFDYkMsUUFBUTtBQUFBLElBQ1JDLGFBQWE7QUFBQSxJQUNiQyxjQUFjO0FBQUEsSUFDZEMsV0FBVztBQUFBLEVBQ2I7QUFDQSxRQUFNQyxjQUFjO0FBQUEsSUFDbEJDLFFBQVE7QUFBQSxFQUNWO0FBRUEsUUFBTSxDQUFDQyxhQUFhQyxjQUFjLElBQUlqQixTQUFTLEtBQUs7QUFFcEQsUUFBTWtCLHNCQUFzQjtBQUFBLElBQUVDLFNBQVNILGNBQWMsU0FBUztBQUFBLEVBQUc7QUFDakUsUUFBTUksc0JBQXNCO0FBQUEsSUFBRUQsU0FBU0gsY0FBYyxLQUFLO0FBQUEsRUFBTztBQUVqRSxRQUFNSyxtQkFBbUJBLE1BQU07QUFDN0JKLG1CQUFlLENBQUNELFdBQVc7QUFBQSxFQUM3QjtBQUVBLFFBQU1NLGFBQWEsWUFBWTtBQUMzQixVQUFNQyxjQUFjO0FBQUEsTUFDbEIsR0FBR3JCO0FBQUFBLE1BQ0hzQixPQUFPdEIsS0FBS3NCLFFBQVE7QUFBQSxJQUN0QjtBQUNBckIsdUJBQW1Cb0IsV0FBVztBQUFBLEVBQ2xDO0FBSUEsUUFBTUUsYUFBYXZCLEtBQUtHLE9BQ3RCQSxLQUFLcUIsTUFBTUMsS0FBS0MsY0FBWUEsU0FBU3ZCLFNBQVNILEtBQUtHLEtBQUt3QixFQUFFLElBQ3hEO0FBR0osU0FDRSx1QkFBQyxTQUNDO0FBQUEsMkJBQUMsU0FBSSxPQUFPWCxxQkFDVixpQ0FBQyxTQUFJLFdBQVUscUJBQW9CLE9BQU9YLFdBQ3ZDTDtBQUFBQSxXQUFLNEI7QUFBQUEsTUFBTTtBQUFBLE1BQUU1QixLQUFLNkI7QUFBQUEsTUFDbkIsdUJBQUMsWUFBTyxTQUFTVixrQkFBa0IsT0FBT1AsYUFBYSxvQkFBdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEyRDtBQUFBLFNBRjdEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHQSxLQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FLQTtBQUFBLElBQ0EsdUJBQUMsU0FBSSxPQUFPTSxxQkFDVixpQ0FBQyxTQUFJLFdBQVUsb0JBQW1CLE9BQU9iLFdBQ3ZDO0FBQUEsNkJBQUMsU0FBSSxXQUFVLGNBQWNMO0FBQUFBLGFBQUs0QjtBQUFBQSxRQUNoQyx1QkFBQyxZQUFPLFNBQVNULGtCQUFrQixPQUFPUCxhQUFhLG9CQUF2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTJEO0FBQUEsV0FEN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLGVBQVksWUFBWVosZUFBSzhCLE9BQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBc0M7QUFBQSxNQUN0Qyx1QkFBQyxTQUFJLGVBQVksY0FBYTtBQUFBO0FBQUEsUUFBUTlCLEtBQUtzQjtBQUFBQSxRQUN6Qyx1QkFBQyxZQUFPLGVBQVksZUFBYyxTQUFTRixZQUFZLE9BQU9SLGFBQWEsb0JBQTNFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBK0U7QUFBQSxXQURqRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSxlQUFlWixlQUFLNkIsVUFBbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEwQztBQUFBLE1BQ3pDTixjQUFjLHVCQUFDLFlBQU8sT0FBT1gsYUFBYSxTQUFTLE1BQU1WLFdBQVdGLElBQUksR0FBRyxzQkFBN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFtRTtBQUFBLFNBVHBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FVQSxLQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FZQTtBQUFBLE9BbkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FvQkE7QUFFSjtBQUFDSSxHQTVES0wsTUFBSTtBQUFBZ0MsS0FBSmhDO0FBOEROLGVBQWVBO0FBQUksSUFBQWdDO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsIkJsb2ciLCJibG9nIiwidXBkYXRlVGhlTGlrZUNvdW50IiwiZGVsZXRlQmxvZyIsInVzZXIiLCJfcyIsImJsb2dTdHlsZSIsInBhZGRpbmdUb3AiLCJwYWRkaW5nTGVmdCIsImJvcmRlciIsImJvcmRlcldpZHRoIiwiYm9yZGVyUmFkaXVzIiwibWFyZ2luVG9wIiwiYnV0dG9uU3R5bGUiLCJtYXJnaW4iLCJpbmZvVmlzaWJsZSIsInNldEluZm9WaXNpYmxlIiwiaGlkZVdoZW5JbmZvVmlzaWJsZSIsImRpc3BsYXkiLCJzaG93V2hlbkluZm9WaXNpYmxlIiwidG9nZ2xlVmlzaWJpbGl0eSIsImhhbmRsZUxpa2UiLCJ1cGRhdGVkQmxvZyIsImxpa2VzIiwiYmxvZ1Bvc3RlciIsImJsb2dzIiwic29tZSIsInVzZXJCbG9nIiwiaWQiLCJ0aXRsZSIsImF1dGhvciIsInVybCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiQmxvZy5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCdcblxuY29uc3QgQmxvZyA9ICh7IGJsb2csIHVwZGF0ZVRoZUxpa2VDb3VudCwgZGVsZXRlQmxvZywgdXNlciB9KSA9PiB7XG4gIGNvbnN0IGJsb2dTdHlsZSA9IHtcbiAgICBwYWRkaW5nVG9wOiA1LFxuICAgIHBhZGRpbmdMZWZ0OiA1LFxuICAgIGJvcmRlcjogJ3NvbGlkJyxcbiAgICBib3JkZXJXaWR0aDogMSxcbiAgICBib3JkZXJSYWRpdXM6IDUsXG4gICAgbWFyZ2luVG9wOiA1LFxuICB9XG4gIGNvbnN0IGJ1dHRvblN0eWxlID0ge1xuICAgIG1hcmdpbjogNSxcbiAgfVxuXG4gIGNvbnN0IFtpbmZvVmlzaWJsZSwgc2V0SW5mb1Zpc2libGVdID0gdXNlU3RhdGUoZmFsc2UpXG5cbiAgY29uc3QgaGlkZVdoZW5JbmZvVmlzaWJsZSA9IHsgZGlzcGxheTogaW5mb1Zpc2libGUgPyAnbm9uZScgOiAnJyB9XG4gIGNvbnN0IHNob3dXaGVuSW5mb1Zpc2libGUgPSB7IGRpc3BsYXk6IGluZm9WaXNpYmxlID8gJycgOiAnbm9uZScgfVxuXG4gIGNvbnN0IHRvZ2dsZVZpc2liaWxpdHkgPSAoKSA9PiB7XG4gICAgc2V0SW5mb1Zpc2libGUoIWluZm9WaXNpYmxlKVxuICB9XG5cbiAgY29uc3QgaGFuZGxlTGlrZSA9IGFzeW5jICgpID0+IHtcbiAgICAgIGNvbnN0IHVwZGF0ZWRCbG9nID0ge1xuICAgICAgICAuLi5ibG9nLFxuICAgICAgICBsaWtlczogYmxvZy5saWtlcyArIDFcbiAgICAgIH1cbiAgICAgIHVwZGF0ZVRoZUxpa2VDb3VudCh1cGRhdGVkQmxvZyk7XG4gIH1cblxuXG4gIC8vIFNlZSBpZiB0aGUgdXNlciBpcyB0aGUgYmxvZyBwb3N0ZXIgKGNoZWNrIGluY2FzZSB0aGUgaXMgbm8gYmxvZy51c2VyIGFzc2lnbmVkIHRvIGEgcG9zdClcbiAgY29uc3QgYmxvZ1Bvc3RlciA9IGJsb2cudXNlciA/XG4gICAgdXNlci5ibG9ncy5zb21lKHVzZXJCbG9nID0+IHVzZXJCbG9nLnVzZXIgPT09IGJsb2cudXNlci5pZClcbiAgICA6IGZhbHNlXG5cblxuICByZXR1cm4gKFxuICAgIDxkaXY+XG4gICAgICA8ZGl2IHN0eWxlPXtoaWRlV2hlbkluZm9WaXNpYmxlfT5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9J2Jsb2ctdGl0bGUtYXV0aG9yJyBzdHlsZT17YmxvZ1N0eWxlfT5cbiAgICAgICAgICB7YmxvZy50aXRsZX0ge2Jsb2cuYXV0aG9yfVxuICAgICAgICAgIDxidXR0b24gb25DbGljaz17dG9nZ2xlVmlzaWJpbGl0eX0gc3R5bGU9e2J1dHRvblN0eWxlfT52aWV3PC9idXR0b24+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgICA8ZGl2IHN0eWxlPXtzaG93V2hlbkluZm9WaXNpYmxlfT5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9J2V4cGFuZGVkQmxvZ1ZpZXcnIHN0eWxlPXtibG9nU3R5bGV9PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPSdibG9nLXRpdGxlJz57YmxvZy50aXRsZX1cbiAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17dG9nZ2xlVmlzaWJpbGl0eX0gc3R5bGU9e2J1dHRvblN0eWxlfT5oaWRlPC9idXR0b24+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGRpdiBkYXRhLXRlc3RpZD1cImJsb2ctdXJsXCI+e2Jsb2cudXJsfTwvZGl2PlxuICAgICAgICAgIDxkaXYgZGF0YS10ZXN0aWQ9XCJibG9nLWxpa2VzXCI+bGlrZXM6IHtibG9nLmxpa2VzfVxuICAgICAgICAgICAgPGJ1dHRvbiBkYXRhLXRlc3RpZD0nbGlrZS1idXR0b24nIG9uQ2xpY2s9e2hhbmRsZUxpa2V9IHN0eWxlPXtidXR0b25TdHlsZX0+bGlrZTwvYnV0dG9uPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPSdibG9nLWF1dGhvcic+e2Jsb2cuYXV0aG9yfTwvZGl2PlxuICAgICAgICAgIHtibG9nUG9zdGVyICYmIDxidXR0b24gc3R5bGU9e2J1dHRvblN0eWxlfSBvbkNsaWNrPXsoKSA9PiBkZWxldGVCbG9nKGJsb2cpfT5kZWxldGU8L2J1dHRvbj59XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gIClcbn1cblxuZXhwb3J0IGRlZmF1bHQgQmxvZyJdLCJmaWxlIjoiL1VzZXJzL2NyYWlnbW9ybGV5L0RvY3VtZW50cy9jb2RpbmcvZnVsbHN0YWNrb3Blbi9wYXJ0NS9ibG9nbGlzdC1mcm9udGVuZC9zcmMvY29tcG9uZW50cy9CbG9nLmpzeCJ9