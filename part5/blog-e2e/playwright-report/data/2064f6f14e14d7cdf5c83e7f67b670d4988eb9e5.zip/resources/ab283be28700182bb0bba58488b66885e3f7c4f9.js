import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/LoginForm.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=c499ffd4"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/craigmorley/Documents/coding/fullstackopen/part5/bloglist-frontend/src/components/LoginForm.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import __vite__cjsImport3_propTypes from "/node_modules/.vite/deps/prop-types.js?v=c499ffd4"; const PropTypes = __vite__cjsImport3_propTypes.__esModule ? __vite__cjsImport3_propTypes.default : __vite__cjsImport3_propTypes;
const LoginForm = ({
  handleSubmit,
  handleUsernameChange,
  handlePasswordChange,
  username,
  password
}) => {
  LoginForm.propTypes = {
    handleSubmit: PropTypes.func.isRequired,
    handleUsernameChange: PropTypes.func.isRequired,
    handlePasswordChange: PropTypes.func.isRequired,
    username: PropTypes.string.isRequired,
    password: PropTypes.string.isRequired
  };
  return /* @__PURE__ */ jsxDEV("form", { onSubmit: handleSubmit, children: [
    /* @__PURE__ */ jsxDEV("div", { children: [
      "username",
      /* @__PURE__ */ jsxDEV("input", { type: "text", name: "username", "data-testid": "username", value: username, onChange: handleUsernameChange, required: true }, void 0, false, {
        fileName: "/Users/craigmorley/Documents/coding/fullstackopen/part5/bloglist-frontend/src/components/LoginForm.jsx",
        lineNumber: 19,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/craigmorley/Documents/coding/fullstackopen/part5/bloglist-frontend/src/components/LoginForm.jsx",
      lineNumber: 17,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { children: [
      "password",
      /* @__PURE__ */ jsxDEV("input", { type: "password", name: "password", "data-testid": "password", value: password, onChange: handlePasswordChange, required: true }, void 0, false, {
        fileName: "/Users/craigmorley/Documents/coding/fullstackopen/part5/bloglist-frontend/src/components/LoginForm.jsx",
        lineNumber: 23,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/craigmorley/Documents/coding/fullstackopen/part5/bloglist-frontend/src/components/LoginForm.jsx",
      lineNumber: 21,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("button", { "data-testid": "login", type: "submit", children: "login" }, void 0, false, {
      fileName: "/Users/craigmorley/Documents/coding/fullstackopen/part5/bloglist-frontend/src/components/LoginForm.jsx",
      lineNumber: 25,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/craigmorley/Documents/coding/fullstackopen/part5/bloglist-frontend/src/components/LoginForm.jsx",
    lineNumber: 16,
    columnNumber: 10
  }, this);
};
_c = LoginForm;
export default LoginForm;
var _c;
$RefreshReg$(_c, "LoginForm");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/craigmorley/Documents/coding/fullstackopen/part5/bloglist-frontend/src/components/LoginForm.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcUJRO0FBckJSLE9BQU9BLG9CQUFlO0FBQVk7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBRWxDLE1BQU1DLFlBQVlBLENBQUM7QUFBQSxFQUNqQkM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFDRixNQUFNO0FBQ0pMLFlBQVVNLFlBQVk7QUFBQSxJQUNwQkwsY0FBY0YsVUFBVVEsS0FBS0M7QUFBQUEsSUFDN0JOLHNCQUFzQkgsVUFBVVEsS0FBS0M7QUFBQUEsSUFDckNMLHNCQUFzQkosVUFBVVEsS0FBS0M7QUFBQUEsSUFDckNKLFVBQVVMLFVBQVVVLE9BQU9EO0FBQUFBLElBQzNCSCxVQUFVTixVQUFVVSxPQUFPRDtBQUFBQSxFQUM3QjtBQUVBLFNBQ0UsdUJBQUMsVUFBSyxVQUFVUCxjQUNkO0FBQUEsMkJBQUMsU0FBRztBQUFBO0FBQUEsTUFFRix1QkFBQyxXQUNDLE1BQUssUUFDTCxNQUFLLFlBQ0wsZUFBWSxZQUNaLE9BQU9HLFVBQ1AsVUFBVUYsc0JBQ1YsVUFBUSxRQU5WO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFNVTtBQUFBLFNBUlo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVVBO0FBQUEsSUFDQSx1QkFBQyxTQUFHO0FBQUE7QUFBQSxNQUVGLHVCQUFDLFdBQ0MsTUFBSyxZQUNMLE1BQUssWUFDTCxlQUFZLFlBQ1osT0FBT0csVUFDUCxVQUFVRixzQkFDVixVQUFRLFFBTlY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU1VO0FBQUEsU0FSWjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBVUE7QUFBQSxJQUNBLHVCQUFDLFlBQU8sZUFBWSxTQUFRLE1BQUssVUFBUyxxQkFBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUErQztBQUFBLE9BdkJqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBd0JBO0FBRUo7QUFBQ08sS0ExQ0tWO0FBNENOLGVBQWVBO0FBQVMsSUFBQVU7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIlByb3BUeXBlcyIsIkxvZ2luRm9ybSIsImhhbmRsZVN1Ym1pdCIsImhhbmRsZVVzZXJuYW1lQ2hhbmdlIiwiaGFuZGxlUGFzc3dvcmRDaGFuZ2UiLCJ1c2VybmFtZSIsInBhc3N3b3JkIiwicHJvcFR5cGVzIiwiZnVuYyIsImlzUmVxdWlyZWQiLCJzdHJpbmciLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkxvZ2luRm9ybS5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFByb3BUeXBlcyBmcm9tICdwcm9wLXR5cGVzJ1xuXG5jb25zdCBMb2dpbkZvcm0gPSAoe1xuICBoYW5kbGVTdWJtaXQsXG4gIGhhbmRsZVVzZXJuYW1lQ2hhbmdlLFxuICBoYW5kbGVQYXNzd29yZENoYW5nZSxcbiAgdXNlcm5hbWUsXG4gIHBhc3N3b3JkXG59KSA9PiB7XG4gIExvZ2luRm9ybS5wcm9wVHlwZXMgPSB7XG4gICAgaGFuZGxlU3VibWl0OiBQcm9wVHlwZXMuZnVuYy5pc1JlcXVpcmVkLFxuICAgIGhhbmRsZVVzZXJuYW1lQ2hhbmdlOiBQcm9wVHlwZXMuZnVuYy5pc1JlcXVpcmVkLFxuICAgIGhhbmRsZVBhc3N3b3JkQ2hhbmdlOiBQcm9wVHlwZXMuZnVuYy5pc1JlcXVpcmVkLFxuICAgIHVzZXJuYW1lOiBQcm9wVHlwZXMuc3RyaW5nLmlzUmVxdWlyZWQsXG4gICAgcGFzc3dvcmQ6IFByb3BUeXBlcy5zdHJpbmcuaXNSZXF1aXJlZFxuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8Zm9ybSBvblN1Ym1pdD17aGFuZGxlU3VibWl0fT5cbiAgICAgIDxkaXY+XG4gICAgICB1c2VybmFtZVxuICAgICAgICA8aW5wdXRcbiAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgbmFtZT1cInVzZXJuYW1lXCJcbiAgICAgICAgICBkYXRhLXRlc3RpZD1cInVzZXJuYW1lXCJcbiAgICAgICAgICB2YWx1ZT17dXNlcm5hbWV9XG4gICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZVVzZXJuYW1lQ2hhbmdlfVxuICAgICAgICAgIHJlcXVpcmVkXG4gICAgICAgIC8+XG4gICAgICA8L2Rpdj5cbiAgICAgIDxkaXY+XG4gICAgICAgIHBhc3N3b3JkXG4gICAgICAgIDxpbnB1dFxuICAgICAgICAgIHR5cGU9XCJwYXNzd29yZFwiXG4gICAgICAgICAgbmFtZT1cInBhc3N3b3JkXCJcbiAgICAgICAgICBkYXRhLXRlc3RpZD1cInBhc3N3b3JkXCJcbiAgICAgICAgICB2YWx1ZT17cGFzc3dvcmR9XG4gICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZVBhc3N3b3JkQ2hhbmdlfVxuICAgICAgICAgIHJlcXVpcmVkXG4gICAgICAgIC8+XG4gICAgICA8L2Rpdj5cbiAgICAgIDxidXR0b24gZGF0YS10ZXN0aWQ9XCJsb2dpblwiIHR5cGU9XCJzdWJtaXRcIj5sb2dpbjwvYnV0dG9uPlxuICAgIDwvZm9ybT5cbiAgKVxufVxuXG5leHBvcnQgZGVmYXVsdCBMb2dpbkZvcm0iXSwiZmlsZSI6Ii9Vc2Vycy9jcmFpZ21vcmxleS9Eb2N1bWVudHMvY29kaW5nL2Z1bGxzdGFja29wZW4vcGFydDUvYmxvZ2xpc3QtZnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvTG9naW5Gb3JtLmpzeCJ9